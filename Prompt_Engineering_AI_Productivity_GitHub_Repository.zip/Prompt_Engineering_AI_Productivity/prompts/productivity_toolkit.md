# AI Productivity Toolkit – Reusable Workflows

## Email writing
Prompt: "Act as a professional communication assistant. Draft a polite email to [RECIPIENT] about [PURPOSE]. Keep it concise, include a clear subject and a courteous closing. Do not invent dates or facts. Use placeholders for missing details."

## Resume improvement
Prompt: "Act as a resume editor. Improve the wording of the experience below using clear action verbs. Do not invent skills, qualifications, numbers or achievements. Return: improved bullet points, keywords to consider, and details I should verify."

## Research assistance
Prompt: "Act as a research assistant. Explain [TOPIC] for a beginner. Separate established facts from suggestions, list questions that need further verification, and provide search terms for reliable sources. Do not invent citations."

## Coding assistance
Prompt: "Act as a patient programming tutor. Explain what this code should do, identify the error, show the smallest corrected version, and explain why it works. Do not change unrelated parts. Include a simple test."

## Study summary
Prompt: "Summarize these notes for exam preparation. Use simple definitions, numbered points, examples and five revision questions. Stay within the supplied notes and flag missing information."

## Human review checklist
- Does the response answer the exact task?
- Is the output in the requested format?
- Are all facts and numbers verified?
- Are there invented details or unsupported claims?
- Is private information protected?
- Does the code run and pass tests?
